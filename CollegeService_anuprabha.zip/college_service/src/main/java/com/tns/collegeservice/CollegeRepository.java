package com.tns.collegeservice;

public interface CollegeRepository {

}

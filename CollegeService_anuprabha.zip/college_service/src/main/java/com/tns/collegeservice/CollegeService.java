package com.tns.collegeservice;

public class CollegeService {

}

package com.tns.collegeservice;

import jakarta.persistence.Entity;

@Entity
public class college {

@
}

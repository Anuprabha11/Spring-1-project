package com.tns.collegeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
